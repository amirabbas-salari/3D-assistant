# Iran Full-Service Digital Agency Agent — Phase 1

## Scope
- Market: Iran
- Agency: Full-service digital marketing
- Conversation style: natural, voice- and chat-friendly
- Domains: Sales and CRM
- Languages: Persian and English
- Intended use: RAG knowledge base + retrieval examples

## Contents
- `knowledge_base/`: 12 authored, source-informed knowledge documents (6 Persian, 6 English)
- `data/processed/documents/documents.jsonl`: document records with metadata
- `data/processed/conversations/conversations.jsonl`: 10 authored synthetic multi-turn scenarios (6 Persian, 4 English)
- `metadata/sources.json`: source register and usage notes
- `metadata/data_card.json`: dataset scope and limitations
- `metadata/taxonomy.json`: domains, statuses and tags
- `schemas/conversation.schema.json`: basic conversation schema
- `evaluation/phase1_test_cases.jsonl`: initial retrieval/answer test questions

## Important data provenance
This is a source-informed starter dataset, not a collection of real customer transcripts.
- Knowledge articles are independently written syntheses based on the cited references.
- Conversation examples are synthetic scenarios designed to cover common agency sales and CRM situations.
- Every source is marked `review_required`. Public accessibility does not automatically grant permission to republish or commercially redistribute source text.
- Do not use these records as verified facts about Iranian market prices, legal requirements, ad-platform availability, or guaranteed performance.

## RAG ingestion recommendations
1. Ingest each Markdown file as a separate document.
2. Preserve `id`, `domain`, `language`, `content_type`, `tags`, `source_ids`, and `review_status` as metadata.
3. Keep Persian and English retrieval filters available; allow cross-language retrieval only if multilingual embedding evaluation supports it.
4. Chunk by headings/semantic sections rather than arbitrary fixed character counts. Start with 450–700 tokens and 60–100 token overlap, then evaluate.
5. Keep conversation scenarios in a separate collection from authoritative knowledge documents. They are examples of conversational behavior, not factual sources.
6. Require citations to source documents for factual answers and abstain when evidence is missing.
7. Do not let the agent invent prices, discounts, guarantees, case studies, or CRM actions.

## Before production
- Have a sales lead and CRM operator review every document.
- Review source licenses/terms for the exact intended use.
- Replace placeholder agency policies (follow-up cadence, qualification thresholds, pricing) with approved internal policies.
- Add real, consented, anonymized call/chat transcripts only after legal/privacy review.
- Add negative and edge cases, then evaluate retrieval and answer faithfulness.

## Source URLs
See `metadata/sources.json` for full URLs, publishers, access date, and usage notes.
